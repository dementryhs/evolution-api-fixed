-- AlterTable
ALTER TABLE "OpenaiBot" ADD COLUMN     "enabled" BOOLEAN NOT NULL DEFAULT true;
