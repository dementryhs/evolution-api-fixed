-- AlterTable
ALTER TABLE "Dify" ADD COLUMN     "description" VARCHAR(255);

-- AlterTable
ALTER TABLE "OpenaiBot" ADD COLUMN     "description" VARCHAR(255);

-- AlterTable
ALTER TABLE "Typebot" ADD COLUMN     "description" VARCHAR(255);
